<?php
// Include file koneksi.php
require_once 'koneksi.php';

// Check connection
if (!isset($koneksi) || !$koneksi) {
    echo json_encode(["status" => "error", "message" => "Koneksi database gagal."]);
    exit;
}

// Set response header
header("Content-Type: application/json");

// Get request method
$method = $_SERVER['REQUEST_METHOD'];

// Parse request
switch ($method) {
    case 'GET':
        // Fetch data barang
        $query = "SELECT * FROM tb_barang";
        $result = mysqli_query($koneksi, $query);

        if ($result) {
            $data = [];
            while ($row = mysqli_fetch_assoc($result)) {
                $data[] = $row;
            }
            echo json_encode(["status" => "success", "data" => $data]);
        } else {
            echo json_encode(["status" => "error", "message" => "Gagal mengambil data."]);
        }
        break;

    case 'POST':
        // Add new barang
        $input = json_decode(file_get_contents('php://input'), true);

        $nama_barang = $input['nama_barang'] ?? '';
        $stok = $input['stok'] ?? 0;
        $harga = $input['harga'] ?? 0;

        $query = "INSERT INTO barang (nama_barang, stok, harga) VALUES ('$nama_barang', '$stok', '$harga')";
        if (mysqli_query($koneksi, $query)) {
            echo json_encode(["status" => "success", "message" => "Barang berhasil ditambahkan"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Gagal menambahkan barang"]);
        }
        break;

    case 'PUT':
        // Update barang
        $input = json_decode(file_get_contents('php://input'), true);

        $id = $input['id'] ?? 0;
        $nama_barang = $input['nama_barang'] ?? '';
        $stok = $input['stok'] ?? 0;
        $harga = $input['harga'] ?? 0;

        $query = "UPDATE barang SET nama_barang='$nama_barang', stok='$stok', harga='$harga' WHERE id='$id'";
        if (mysqli_query($koneksi, $query)) {
            echo json_encode(["status" => "success", "message" => "Barang berhasil diperbarui"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Gagal memperbarui barang"]);
        }
        break;

    case 'DELETE':
        // Delete barang
        $input = json_decode(file_get_contents('php://input'), true);

        $id = $input['id'] ?? 0;

        $query = "DELETE FROM barang WHERE id='$id'";
        if (mysqli_query($koneksi, $query)) {
            echo json_encode(["status" => "success", "message" => "Barang berhasil dihapus"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Gagal menghapus barang"]);
        }
        break;

    default:
        echo json_encode(["status" => "error", "message" => "Metode tidak valid"]);
        break;
}

// Close the connection
mysqli_close($koneksi);
?>
